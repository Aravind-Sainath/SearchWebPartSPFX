declare const styles: {
    panelContainer: string;
    divElement: string;
};
export default styles;
//# sourceMappingURL=CarouselWebpart.module.scss.d.ts.map