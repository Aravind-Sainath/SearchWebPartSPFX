import * as React from 'react';
import { ICarouselWebpartProps, IDefaultCarousel } from './ICarouselWebpartProps';
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { IFilePickerResult } from '@pnp/spfx-controls-react/lib';
export default class CarouselWebpart extends React.Component<ICarouselWebpartProps, IDefaultCarousel> {
    constructor(props: any);
    componentDidMount(): void;
    componentDidUpdate(): void;
    getImageUrl(file: IFilePickerResult): void;
    getSliderDetails(): void;
    getLayout(): void;
    getHtmlText(): void;
    gettingValues(event: any, value: any): void;
    buttonClick(): void;
    applyLayout(): void;
    render(): React.ReactElement<ICarouselWebpartProps>;
}
//# sourceMappingURL=CarouselWebpart.d.ts.map