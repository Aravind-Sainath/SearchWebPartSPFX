import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
export interface ICarouselWebpartWebPartProps {
    layout: string;
}
export default class CarouselWebpartWebPart extends BaseClientSideWebPart<ICarouselWebpartWebPartProps> {
    private listItems;
    render(): void;
    protected onDispose(): void;
    protected readonly dataVersion: Version;
    protected onPropertyPaneConfigurationStart(): void;
    protected readonly disableReactivePropertyChanges: boolean;
    onPropertyPaneFieldChanged(): void;
    private loadListItems;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=CarouselWebpartWebPart.d.ts.map