/* tslint:disable */
require("./CarouselWebpart.module.css");
const styles = {
  panelContainer: 'panelContainer_172353e4',
  divElement: 'divElement_172353e4'
};

export default styles;
/* tslint:enable */