import { WebPartContext } from "@microsoft/sp-webpart-base";

export interface ICarouselWebpartProps {
  layout: string;
  context: WebPartContext;
  pane: boolean;
}

export interface IDefaultCarousel{
  defCarousel: boolean;
  ImageURL: string;
  SliderCaption: string;
  SliderDescription: string;
  SliderHyperlink: string;
  SliderMscText: string;
  SliderSmallText: string;
  SliderSubHTML: string;
  previewFlag: boolean;
}