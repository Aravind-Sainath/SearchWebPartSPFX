import * as React from 'react';
import styles from './CarouselWebpart.module.scss';
import { ICarouselWebpartProps, IDefaultCarousel } from './ICarouselWebpartProps';
import { SPHttpClient } from '@microsoft/sp-http';
import { Panel, PanelType } from 'office-ui-fabric-react/lib/Panel';
import { TextField } from 'office-ui-fabric-react/lib/TextField';
import { PrimaryButton, Button } from 'office-ui-fabric-react';
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { FilePicker, IFilePickerResult } from '@pnp/spfx-controls-react/lib';
import ReactHtmlParser from 'react-html-parser';
var columnNames = [];
var imgDataArray = [];
var defHtmlContent = "";
var htmlLayout = "";
var Mode; 

//function to change the color of Arros
function SampleNextArrow(props) {
  const { className, style, onClick } = props;
  return (
    <div
      className={className}
      style={{ ...style, display: "block", background: "grey" }}
      onClick={onClick}
    />
  );
}

function SamplePrevArrow(props) {
  const { className, style, onClick } = props;
  return (
    <div
      className={className}
      style={{ ...style, display: "block", background: "grey" }}
      onClick={onClick}
    />
  );
}

export default class CarouselWebpart extends React.Component<ICarouselWebpartProps, IDefaultCarousel> {
  constructor(props){
    super(props);
    debugger;
    const queryString = window.location.search;
    const urlParams = new URLSearchParams(queryString);
    Mode = urlParams.get('Mode');
    //Initializing the State
    this.state = {
      defCarousel: false,
      ImageURL: "",
      SliderCaption: "",
      SliderDescription: "",
      SliderHyperlink: "",
      SliderMscText: "",
      SliderSmallText: "",
      SliderSubHTML: "",
      previewFlag: false,
    }
    //binding the funtions
    this.getSliderDetails = this.getSliderDetails.bind(this);    
    this.getLayout = this.getLayout.bind(this);
    this.getImageUrl = this.getImageUrl.bind(this);
    this.gettingValues = this.gettingValues.bind(this);
    this.buttonClick = this.buttonClick.bind(this);
    this.getHtmlText = this.getHtmlText.bind(this);
    this.applyLayout = this.applyLayout.bind(this);
  }
  componentDidMount(){
    this.getSliderDetails();
    this.getLayout();
  }

  componentDidUpdate(){
    if(!this.props.pane){  
      this.getLayout();
    }
  }
  //Getting Image URL
  getImageUrl(file: IFilePickerResult) {
    this.setState({ ImageURL: file.fileAbsoluteUrl });
  }

  //get all the details from Slider List
  getSliderDetails(){
    var tenentURL = this.props.context.pageContext.web.absoluteUrl;
    tenentURL = tenentURL.replace(this.props.context.pageContext.web.serverRelativeUrl,"");
    let restUrl = this.props.context.pageContext.web.absoluteUrl +"/_api/web/lists/getbytitle('Slider List')/Fields?$filter=Hidden eq false and ReadOnlyField eq false"
      this.props.context.spHttpClient.get(restUrl, SPHttpClient.configurations.v1).then((response) => {
        if(response.ok){
          response.json().then(data =>{
            data.value.map((list) => {
              columnNames.push(list.Title);
            });
            columnNames.splice(columnNames.indexOf('Title'), 1);
            //columnNames.splice(columnNames.indexOf('Name'), 1);
            columnNames.splice(columnNames.indexOf('Content Type'), 1);
            let restUrl = this.props.context.pageContext.web.absoluteUrl +"/_api/web/lists/getbytitle('Slider List')/items?$expand=File"
            this.props.context.spHttpClient.get(restUrl, SPHttpClient.configurations.v1).then((response) => {
              if(response.ok){
                response.json().then(data =>{
                  data.value.map((list) => {
                    var imgData = {}
                    columnNames.forEach(element => {
                      imgData[element]= list[element]
                    });
                    imgData["Name"] = tenentURL + list.File.ServerRelativeUrl;
                    imgDataArray.push(imgData);
                  });
                });
              }
            });
          });
        }
      });
  }

  //Getting layout and displaying it in Carousel
  getLayout(){
    if(this.props.layout==undefined || this.props.layout ==""){
      defHtmlContent = "";
      let restUrl = this.props.context.pageContext.web.absoluteUrl +"/_api/web/GetFolderByServerRelativeUrl('/DemoSite/SiteAssets/Layouts')/Files"
        this.props.context.spHttpClient.get(restUrl, SPHttpClient.configurations.v1).then((response) => {
          if(response.ok){
            response.json().then(data =>{
              let layoutData = this.props.context.pageContext.web.absoluteUrl +"/_api/web/GetFileByServerRelativeUrl('/DemoSite/SiteAssets/Layouts/"+data.value[0].Name+"')"
              this.props.context.spHttpClient.get(layoutData, SPHttpClient.configurations.v1).then((response) => {
                if(response.ok){
                  response.json().then(data =>{
                    fetch(data.ServerRelativeUrl).then((r) => r.text()).then(text =>{
                      defHtmlContent = ""
                      imgDataArray.forEach(element => {
                        var htmltext = text;
                        defHtmlContent =defHtmlContent + "<div>";
                        columnNames.forEach(col => {
                          htmltext = htmltext.replace(col, element[col]);
                        });
                        defHtmlContent = defHtmlContent + htmltext;
                        defHtmlContent =defHtmlContent + "</div>";
                      });
                      this.setState({
                        defCarousel: true,
                      });
                    });
                  });
                }
              });
            });
          }
        });
    }else{
      let layoutData = this.props.context.pageContext.web.absoluteUrl +"/_api/web/GetFileByServerRelativeUrl('/DemoSite/SiteAssets/Layouts/"+this.props.layout+"')"
              this.props.context.spHttpClient.get(layoutData, SPHttpClient.configurations.v1).then((response) => {
                if(response.ok){
                  response.json().then(data =>{
                    fetch(data.ServerRelativeUrl).then((r) => r.text()).then(text =>{
                      defHtmlContent="";
                      imgDataArray.forEach(element => {
                        var htmltext = text;
                        defHtmlContent =defHtmlContent + "<div>";
                        columnNames.forEach(col => {
                          htmltext = htmltext.replace(col, element[col]);
                        });
                        defHtmlContent = defHtmlContent + htmltext;
                        defHtmlContent =defHtmlContent + "</div>";
                      });
                      debugger;
                      this.setState({
                        defCarousel: true,
                      });
                    });
                  });
                }
              }); 
    }
  }

  // getting HTML text and setting preview Image
  getHtmlText(){
    var SliderCaption = this.state.SliderCaption;
    var SliderDescription = this.state.SliderDescription;
    var SliderHyperlink = this.state.SliderHyperlink;
    var SliderMscText = this.state.SliderMscText;
    var SliderSmallText = this.state.SliderSmallText;
    var SliderSubHTML = this.state.SliderSubHTML;
    let layoutData = this.props.context.pageContext.web.absoluteUrl +"/_api/web/GetFileByServerRelativeUrl('/DemoSite/SiteAssets/Layouts/"+this.props.layout+"')"
    this.props.context.spHttpClient.get(layoutData, SPHttpClient.configurations.v1).then((response) => {
      if(response.ok){
        response.json().then(data =>{
          fetch(data.ServerRelativeUrl).then((r) => r.text()).then(text =>{
            htmlLayout = text;
            htmlLayout = htmlLayout.replace("SliderCaption", SliderCaption);
            htmlLayout = htmlLayout.replace("SliderDescription", SliderDescription);
            htmlLayout = htmlLayout.replace("SliderHyperlink", SliderHyperlink);
            htmlLayout = htmlLayout.replace("SliderMscText", SliderMscText);
            htmlLayout = htmlLayout.replace("SliderSmallText", SliderSmallText);
            htmlLayout = htmlLayout.replace("SliderSubHTML", SliderSubHTML);
            htmlLayout = htmlLayout.replace("Name", this.state.ImageURL);
            debugger;
            this.setState({
              previewFlag: true,
            });
          });
        });
      }
    });
  }

  gettingValues(event, value){
    const settingState = {[event.target.name]: value} as Pick<IDefaultCarousel, keyof IDefaultCarousel>
    this.setState(settingState);
  }
  
  //Preview button on click
  buttonClick(){
    this.getHtmlText();
  }

  applyLayout(){
    window.location.reload();
  }
  public render(): React.ReactElement<ICarouselWebpartProps> {
    const settings = {
      dots: true,
      infinite: true,
      fade: true,
      adaptiveHeight: true,
      autoplay: true,
      speed: 2000,
      autoplaySpeed: 2000,
      slidesToShow: 1,
      slidesToScroll: 1,
      nextArrow: <SampleNextArrow />,
      prevArrow: <SamplePrevArrow />
    };
    return (
      <div>
      <Slider {...settings}>
      {ReactHtmlParser(defHtmlContent)}
      </Slider>
    <Panel
        isOpen={this.props.pane}
        type={PanelType.large}
        className = {styles["PanelClass"]}
        closeButtonAriaLabel="Close"
        headerText="Edit Properties"
      >
        <div className={styles["panelContainer"]}>
          <div className = {styles["divElement"]}>
            <h3>Preview Panel</h3>
            <p>You can see Preview here</p>
            <br />
            {!(this.state.previewFlag)? <img style={{width: "100%", filter: "blur(3px)"}} src={this.state.ImageURL} />: <div>{ReactHtmlParser(htmlLayout)}<br /><br /><PrimaryButton text="Apply" onClick={this.applyLayout.bind(this)}/></div>}
            
          </div>
          <div className = {styles["divElement"]}>
            <h3>Properties</h3>
            <FilePicker
              label={'Select or upload image'}
              buttonLabel={'Images'}
              accepts={[".gif", ".jpg", ".jpeg", ".bmp", ".dib", ".tif", ".tiff", ".ico", ".png", ".jxr", ".svg"]}
              buttonIcon="FileImage"
              onSave={this.getImageUrl}
              onChanged={this.getImageUrl}
              context={this.props.context}
            />
            <TextField onChange={this.gettingValues.bind(this)} name="SliderCaption" label="Slider Caption" />
            <TextField onChange={this.gettingValues.bind(this)} name="SliderDescription" label="Slider Description" />
            <TextField onChange={this.gettingValues.bind(this)} name="SliderHyperlink" label="Slider Hyperlink" />
            <TextField onChange={this.gettingValues.bind(this)} name="SliderMscText" label="Slider Msc Text" />
            <TextField onChange={this.gettingValues.bind(this)} name="SliderSmallText" label="Slider Small Text" />
            <TextField onChange={this.gettingValues.bind(this)} name="SliderSubHTML" label="Slider SubHTML" />
            <br />
            <PrimaryButton text="Preview" onClick = {this.buttonClick.bind(this)}/> &nbsp;&nbsp;&nbsp;&nbsp;
            {/* <Button text = "Close" onClick = {this.applyLayout.bind(this)} /> */}
          </div>
        </div>
      </Panel>
    </div>
    );
  }
}
