import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  IPropertyPaneConfiguration,
  PropertyPaneDropdown
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart, IPropertyPaneDropdownOption } from '@microsoft/sp-webpart-base';

import * as strings from 'CarouselWebpartWebPartStrings';
import CarouselWebpart from './components/CarouselWebpart';
import { ICarouselWebpartProps } from './components/ICarouselWebpartProps';

import { SPHttpClient } from '@microsoft/sp-http';

export interface ICarouselWebpartWebPartProps {
  layout: string;
}
var pane;

export default class CarouselWebpartWebPart extends BaseClientSideWebPart<ICarouselWebpartWebPartProps> {
  private listItems: IPropertyPaneDropdownOption[] = null;
  public render(): void {
    const element: React.ReactElement<ICarouselWebpartProps> = React.createElement(
      CarouselWebpart,
      {
        layout: this.properties.layout,
        context: this.context,
        pane: pane,
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

    //Function for property pane onLoad
    protected onPropertyPaneConfigurationStart(): void{
      if(this.listItems){
        return;
      }
      this.loadListItems().then((listOptions: IPropertyPaneDropdownOption[]): void => {
        this.listItems = listOptions;
        this.context.propertyPane.refresh();
      })
    }

    //Function to stop rendering until click on Apply Button
    protected get disableReactivePropertyChanges(): boolean{
      return true;
    }

    //On dropdown change function
    onPropertyPaneFieldChanged(){
      pane = true;
      this.context.propertyPane.refresh()
    }

    //loading dropdown values
  private loadListItems(): Promise<IPropertyPaneDropdownOption[]>{
    return new Promise<IPropertyPaneDropdownOption[]>((resolve: (options: IPropertyPaneDropdownOption[]) => void, reject:(error: any) => void) =>{
      let restUrl = this.context.pageContext.web.absoluteUrl +"/_api/web/GetFolderByServerRelativeUrl('/DemoSite/SiteAssets/Layouts')/Files"
      this.context.spHttpClient.get(restUrl, SPHttpClient.configurations.v1).then((response) => {
        if(response.ok){
          response.json().then(data =>{
            let result = data.value.map((list) => {
              return {key: list.Name, text: list.Name}
            });
            resolve(result);
          })
        }
      });
    });
  }
  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: "",
              groupFields: [
                PropertyPaneDropdown('layout',{
                  label: "Select a Layout",
                  options: this.listItems
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
