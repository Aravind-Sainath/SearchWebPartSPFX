declare interface ICarouselWebpartWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'CarouselWebpartWebPartStrings' {
  const strings: ICarouselWebpartWebPartStrings;
  export = strings;
}
